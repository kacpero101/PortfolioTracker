//
//  AssetType.swift
//  PortfolioTracker
//
//  Definiuje klasy aktywów, które użytkownik może dodać do portfela.
//

import SwiftUI

/// Klasa aktywa - decyduje m.in. o tym, czy cena ma być pobierana
/// automatycznie (akcje, ETF-y, krypto) czy wpisywana ręcznie (obligacje, gotówka).
enum AssetType: String, Codable, CaseIterable, Identifiable {
    case stock = "Akcja"
    case etf = "ETF"
    case bond = "Obligacja"
    case cash = "Gotówka"
    case crypto = "Kryptowaluta"

    var id: String { rawValue }

    /// Czy dla tego typu aktywa próbujemy pobrać cenę z Yahoo Finance.
    /// Obligacje i gotówka nie mają jednego, uniwersalnego tickera giełdowego,
    /// więc ich wycena jest ustalana ręcznie przez użytkownika.
    var autoFetchesPrice: Bool {
        switch self {
        case .stock, .etf, .crypto:
            return true
        case .bond, .cash:
            return false
        }
    }

    /// Kolor używany na wykresie kołowym alokacji.
    var color: Color {
        switch self {
        case .stock: return .blue
        case .etf: return .green
        case .bond: return .orange
        case .cash: return .gray
        case .crypto: return .purple
        }
    }

    /// Krótka podpowiedź, jak wpisać ticker dla danego typu.
    var tickerHint: String {
        switch self {
        case .stock: return "np. AAPL, CDR.WA (dla GPW dodaj .WA)"
        case .etf: return "np. VOO, SPY, IWDA.L"
        case .crypto: return "np. BTC, ETH (dopiszemy -USD automatycznie)"
        case .bond, .cash: return "ticker niewymagany"
        }
    }
}
