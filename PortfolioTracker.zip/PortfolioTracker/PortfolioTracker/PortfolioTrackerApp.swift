//
//  PortfolioTrackerApp.swift
//  PortfolioTracker
//
//  Punkt startowy aplikacji.
//

import SwiftUI

@main
struct PortfolioTrackerApp: App {
    // @StateObject tworzy PortfolioStore raz i utrzymuje go przez cały cykl życia aplikacji.
    @StateObject private var store = PortfolioStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .frame(minWidth: 800, minHeight: 600)
                .task {
                    // Odświeżamy ceny automatycznie przy uruchomieniu programu.
                    await store.refreshPrices()
                }
        }
        .windowResizability(.contentSize)
    }
}
