//
//  AllocationChartView.swift
//  PortfolioTracker
//
//  Wykres kołowy pokazujący procentową alokację portfela
//  między klasami aktywów (akcje, ETF-y, obligacje, gotówka, krypto).
//
//  Wymaga frameworka Swift Charts (macOS 13+ / Xcode 14+).
//

import SwiftUI
import Charts

struct AllocationChartView: View {
    let entries: [PortfolioStore.AllocationEntry]

    var body: some View {
        HStack(spacing: 24) {
            Chart(entries) { entry in
                SectorMark(
                    angle: .value("Wartość", entry.value),
                    innerRadius: .ratio(0.55),
                    angularInset: 1.5
                )
                .foregroundStyle(entry.type.color)
                .cornerRadius(4)
            }
            .chartLegend(.hidden)
            .frame(maxWidth: .infinity)

            // Własna legenda zamiast domyślnej - czytelniejsza z wartościami procentowymi.
            VStack(alignment: .leading, spacing: 10) {
                ForEach(entries) { entry in
                    HStack {
                        Circle()
                            .fill(entry.type.color)
                            .frame(width: 10, height: 10)
                        Text(entry.type.rawValue)
                        Spacer()
                        Text(String(format: "%.1f%%", entry.percent))
                            .foregroundStyle(.secondary)
                    }
                    .font(.callout)
                }
            }
            .frame(width: 180)
        }
    }
}

#Preview {
    AllocationChartView(entries: [
        .init(type: .stock, value: 6000, percent: 60),
        .init(type: .etf, value: 3000, percent: 30),
        .init(type: .cash, value: 1000, percent: 10)
    ])
    .frame(height: 260)
    .padding()
}
